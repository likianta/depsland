from argsense import cli
from depsland import pypi


@cli.cmd()
def make(dst_dir: str, requirements_file: str = None):
    pass


@cli.cmd('add')
def add_package(dst_dir: str, package_name: str):
    pass
