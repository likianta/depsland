from depsland import pypi

print(':l',
      pypi.name_2_versions,
      pypi.name_id_2_paths,
      pypi.dependencies,
      pypi.updates)
